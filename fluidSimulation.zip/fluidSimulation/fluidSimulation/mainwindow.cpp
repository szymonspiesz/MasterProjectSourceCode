#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "iostream"


int IX(int x, int y, int z){


    if(x < 0) x = 0;
    if(x > N - 1) x = N - 1;

    if(y < 0) y = 0;
    if(y > N - 1) y = N - 1;

    if(z < 0) z = 0;
    if(z > N - 1) z = N - 1;

    return x + y * N + z * N * N;
}

//index function for grid indices (grid built with (N+1)*(N+1)*(N+1) vertices)
int index(int x, int y, int z){

    return x + y * (N+1) + z * (N+1) * (N+1);
}


//function for calculating distance between points
float dist(QVector3D a, QVector3D b){

    return sqrt(  (b.x() - a.x()) * (b.x() - a.x())
                + (b.y() - a.y()) * (b.y() - a.y())
                + (b.z() - a.z()) * (b.z() - a.z())
               );
}

//which neighbour has shortest distance from current cube to destination
int closestNeighbour(std::vector<QVector3D> neighbours, QVector3D destination){

    int closestN; // neighbour closest to destination

    float temp;
    float shortestDist = 1000;

    temp = dist(neighbours[0], destination);

    for(int i = 0; i < neighbours.size(); ++i){
        temp = dist(neighbours[i], destination);
        if(temp <= shortestDist) {
            closestN = i;
            shortestDist = temp;
        }
    }
    return closestN;
}

//find path from lightSource(start) to a given cube in a grid(dest)
std::vector<QVector3D> findPath(QVector3D start, QVector3D dest){

    std::vector<QVector3D> path;
    std::vector<QVector3D> currentCubeNeighbours;

    QVector3D currentCube = start;
    int nextCubeID;

    float currX, currY, currZ;

    while(currentCube != dest){

        currX = currentCube.x();
        currY = currentCube.y();
        currZ = currentCube.z();

        //fill a vector with neighbours of current cube
        //MID
        currentCubeNeighbours.push_back(QVector3D(currX-1, currY, currZ-1));
        currentCubeNeighbours.push_back(QVector3D(currX-1, currY, currZ));
        currentCubeNeighbours.push_back(QVector3D(currX-1, currY, currZ+1));
        currentCubeNeighbours.push_back(QVector3D(currX,   currY, currZ-1));
        currentCubeNeighbours.push_back(QVector3D(currX,   currY, currZ+1));
        currentCubeNeighbours.push_back(QVector3D(currX+1, currY, currZ-1));
        currentCubeNeighbours.push_back(QVector3D(currX+1, currY, currZ));
        currentCubeNeighbours.push_back(QVector3D(currX+1, currY, currZ+1));
        //BOTTOM
        currentCubeNeighbours.push_back(QVector3D(currX-1, currY-1, currZ-1));
        currentCubeNeighbours.push_back(QVector3D(currX-1, currY-1, currZ));
        currentCubeNeighbours.push_back(QVector3D(currX-1, currY-1, currZ+1));
        currentCubeNeighbours.push_back(QVector3D(currX,   currY-1, currZ-1));
        currentCubeNeighbours.push_back(QVector3D(currX,   currY-1, currZ));
        currentCubeNeighbours.push_back(QVector3D(currX,   currY-1, currZ+1));
        currentCubeNeighbours.push_back(QVector3D(currX+1, currY-1, currZ-1));
        currentCubeNeighbours.push_back(QVector3D(currX+1, currY-1, currZ));
        currentCubeNeighbours.push_back(QVector3D(currX+1, currY-1, currZ+1));
        //TOP
        currentCubeNeighbours.push_back(QVector3D(currX-1, currY+1, currZ-1));
        currentCubeNeighbours.push_back(QVector3D(currX-1, currY+1, currZ));
        currentCubeNeighbours.push_back(QVector3D(currX-1, currY+1, currZ+1));
        currentCubeNeighbours.push_back(QVector3D(currX,   currY+1, currZ-1));
        currentCubeNeighbours.push_back(QVector3D(currX,   currY+1, currZ));
        currentCubeNeighbours.push_back(QVector3D(currX,   currY+1, currZ+1));
        currentCubeNeighbours.push_back(QVector3D(currX+1, currY+1, currZ-1));
        currentCubeNeighbours.push_back(QVector3D(currX+1, currY+1, currZ));
        currentCubeNeighbours.push_back(QVector3D(currX+1, currY+1, currZ+1));

        //check which neighbour of current cube is the closest to destination
        nextCubeID = closestNeighbour(currentCubeNeighbours, dest);
        //add that neighbour to a path
        path.push_back(currentCubeNeighbours[nextCubeID]);
        //make that neighbour current
        currentCube = currentCubeNeighbours[nextCubeID];

        currentCubeNeighbours.clear();
    }
    return path;
}


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    this->resize(N*scale,N*scale);

    openglWindow *ogl = new openglWindow();

    QWidget *container = QWidget::createWindowContainer(ogl);
    container->resize(N*scale,N*scale);

    this->layout()->addWidget(container);
}

MainWindow::~MainWindow()
{
    delete ui;
}

Fluid::Fluid(float timeStep, float diffusion, float viscosity){


    this->timeStep = timeStep;
    this->viscosity = viscosity;
    this->diffusion = diffusion;

    for(int i = 0; i < N*N*N; i++){

        prevDensity.push_back(0);
        density.push_back(0);

        velocX.push_back(0);
        velocY.push_back(0);
        velocZ.push_back(0);

        prevValX.push_back(0);
        prevValY.push_back(0);
        prevValZ.push_back(0);

    }

    float densPower = 50;

    //density
    density[IX(10,1,10)] = densPower;
    density[IX(10,1,11)] = densPower;
    density[IX(10,1,12)] = densPower;

    density[IX(11,1,10)] = densPower;
    density[IX(11,1,11)] = densPower;
    density[IX(11,1,12)] = densPower;

    density[IX(12,1,10)] = densPower;
    density[IX(12,1,11)] = densPower;
    density[IX(12,1,12)] = densPower;


    density[IX(9,1,9)]   = densPower;
    density[IX(9,1,10)]  = densPower;
    density[IX(9,1,11)]  = densPower;
    density[IX(9,1,12)]  = densPower;
    density[IX(9,1,13)]  = densPower;

    density[IX(10,1,9)]  = densPower;
    density[IX(10,1,13)] = densPower;

    density[IX(11,1,9)]  = densPower;
    density[IX(11,1,13)] = densPower;

    density[IX(12,1,9)]  = densPower;
    density[IX(12,1,13)] = densPower;

    density[IX(13,1,9)]  = densPower;
    density[IX(13,1,10)] = densPower;
    density[IX(13,1,11)] = densPower;
    density[IX(13,1,12)] = densPower;
    density[IX(13,1,13)] = densPower;

    //velocity y axis
    float v0 = 14.7f;
    //velocity on sides
    float v1 = 1.2f;

    //velocity bottom//
    //cube1
    velocX[IX(10,1,10)] = -v1;
    velocY[IX(10,1,10)] = v0;
    velocZ[IX(10,1,10)] = -v1;
    //cube2
    velocX[IX(10,1,11)] = -v1;
    velocY[IX(10,1,11)] = v0;
    //cube3
    velocX[IX(10,1,12)] = -v1;
    velocY[IX(10,1,12)] = v0;
    velocZ[IX(10,1,12)] = v1;
    //cube4
    velocY[IX(11,1,10)] = v0;
    velocZ[IX(11,1,10)] = -v1;
    //cube5
    velocY[IX(11,1,11)] = v0;
    //cube6
    velocY[IX(11,1,12)] = v0;
    velocZ[IX(11,1,12)] = v1;
    //cube7
    velocX[IX(12,1,10)] = v1;
    velocY[IX(12,1,10)] = v0;
    velocZ[IX(12,1,10)] = -v1;
    //cube8
    velocX[IX(12,1,11)] = v1;
    velocY[IX(12,1,11)] = v0;
    //cube9
    velocX[IX(12,1,12)] = v1;
    velocY[IX(12,1,12)] = v0;
    velocZ[IX(12,1,12)] = v1;


    //"wind"

    velocX[IX(13,1,9)] = 5;
    velocZ[IX(13,1,9)] = -5;

    velocZ[IX(11,1,9)] = -5;

    velocX[IX(9,1,9)] = -5;
    velocZ[IX(9,1,9)] = -5;

    velocX[IX(9,1,11)] = 5;

    velocX[IX(9,1,13)] = -5;
    velocZ[IX(9,1,13)] = 5;

    velocZ[IX(11,1,13)] = -5;

    velocX[IX(13,1,13)] = 5;
    velocZ[IX(13,1,13)] = 5;

    velocX[IX(13,1,11)] = 5;



    //stop the smoke from going too hight and hitting the top of the grid
    v0 = -9.8f;
    //spread the smoke on the sides on the top
    v1 = 7.8f;
    //velocity on the top of the grid
    int explosionHeight = N - 5;

    //cube1
    this->velocX[IX(10,explosionHeight,10)] = -v1;
    this->velocY[IX(10,explosionHeight,10)] = v0;
    this->velocZ[IX(10,explosionHeight,10)] = -v1;
    //cube2
    this->velocX[IX(10,explosionHeight,11)] = -v1;
    this->velocY[IX(10,explosionHeight,11)] = v0;
    //cube3
    this->velocX[IX(10,explosionHeight,12)] = -v1;
    this->velocY[IX(10,explosionHeight,12)] = v0;
    this->velocZ[IX(10,explosionHeight,12)] = v1;
    //cube4
    this->velocY[IX(11,explosionHeight,10)] = v0;
    this->velocZ[IX(11,explosionHeight,10)] = -v1;
    //cube5
    this->velocY[IX(11,explosionHeight,11)] = -11.4f;
    //cube6
    this->velocY[IX(11,explosionHeight,12)] = v0;
    this->velocZ[IX(11,explosionHeight,12)] = v1;
    //cube7
    this->velocX[IX(12,explosionHeight,10)] = v1;
    this->velocY[IX(12,explosionHeight,10)] = v0;
    this->velocZ[IX(12,explosionHeight,10)] = -v1;
    //cube8
    this->velocX[IX(12,explosionHeight,11)] = v1;
    this->velocY[IX(12,explosionHeight,11)] = v0;
    //cube9
    this->velocX[IX(12,explosionHeight,12)] = v1;
    this->velocY[IX(12,explosionHeight,12)] = v0;
    this->velocZ[IX(12,explosionHeight,12)] = v1;


}

void Fluid::addDensity(int x, int y, int z, float amount){
    this->density[IX(x, y, z)] += amount;
}

void Fluid::addVelocity(int x, int y, int z, float amountX, float amountY, float amountZ){

    int index = IX(x, y, z);

    this->velocX[index] += amountX;
    this->velocY[index] += amountY;
    this->velocZ[index] += amountZ;

}



void Fluid::setBoundary(int xyz, std::vector<float>* x)
{
    //z value
    for(int j = 1; j < N - 1; j++) {
        for(int i = 1; i < N - 1; i++) {
            if(xyz == 3){
                x->at(IX(i, j, 0  )) = -x->at(IX(i, j, 1  ));
                x->at(IX(i, j, N-1)) = -x->at(IX(i, j, N-2));
            }
            else{
                x->at(IX(i, j, 0  )) = x->at(IX(i, j, 1  ));
                x->at(IX(i, j, N-1)) = x->at(IX(i, j, N-2));
            }
        }
    }

    //y value
    for(int k = 1; k < N - 1; k++) {
        for(int i = 1; i < N - 1; i++) {
            if(xyz == 2){
                x->at(IX(i, 0  , k)) = -x->at(IX(i, 1  , k));
                x->at(IX(i, N-1, k)) = -x->at(IX(i, N-2, k));
            }
            else{
                x->at(IX(i, 0  , k)) = x->at(IX(i, 1  , k));
                x->at(IX(i, N-1, k)) = x->at(IX(i, N-2, k));
            }
        }
    }

    //x value
    for(int k = 1; k < N - 1; k++) {
        for(int j = 1; j < N - 1; j++) {
            if(xyz == 1){
                x->at(IX(0  , j, k)) = -x->at(IX(1  , j, k));
                x->at(IX(N-1, j, k)) = -x->at(IX(N-2, j, k));
            }
            else{
                x->at(IX(0  , j, k)) = x->at(IX(1  , j, k));
                x->at(IX(N-1, j, k)) = x->at(IX(N-2, j, k));
            }
        }
    }

    //set the corners
    x->at(IX(0, 0, 0))       = 0.33f * (x->at(IX(1, 0, 0))       + x->at(IX(0, 1, 0))       + x->at(IX(0, 0, 1)));
    x->at(IX(0, N-1, 0))     = 0.33f * (x->at(IX(1, N-1, 0))     + x->at(IX(0, N-2, 0))     + x->at(IX(0, N-1, 1)));
    x->at(IX(0, 0, N-1))     = 0.33f * (x->at(IX(1, 0, N-1))     + x->at(IX(0, 1, N-1))     + x->at(IX(0, 0, N)));
    x->at(IX(0, N-1, N-1))   = 0.33f * (x->at(IX(1, N-1, N-1))   + x->at(IX(0, N-2, N-1))   + x->at(IX(0, N-1, N-2)));
    x->at(IX(N-1, 0, 0))     = 0.33f * (x->at(IX(N-2, 0, 0))     + x->at(IX(N-1, 1, 0))     + x->at(IX(N-1, 0, 1)));
    x->at(IX(N-1, N-1, 0))   = 0.33f * (x->at(IX(N-2, N-1, 0))   + x->at(IX(N-1, N-2, 0))   + x->at(IX(N-1, N-1, 1)));
    x->at(IX(N-1, 0, N-1))   = 0.33f * (x->at(IX(N-2, 0, N-1))   + x->at(IX(N-1, 1, N-1))   + x->at(IX(N-1, 0, N-2)));
    x->at(IX(N-1, N-1, N-1)) = 0.33f * (x->at(IX(N-2, N-1, N-1)) + x->at(IX(N-1, N-2, N-1)) + x->at(IX(N-1, N-1, N-2)));
}

void Fluid::linearSolve(int xyz, std::vector<float>* x, std::vector<float>* x0, float a, float c){

    for (int k = 0; k < iterations; k++) {
        for (int m = 1; m < N - 1; m++) {
            for (int j = 1; j < N - 1; j++) {
                for (int i = 1; i < N - 1; i++) {
                    x->at(IX(i, j, m)) = (x0->at(IX(i, j, m))+ a*

                                         (x->at(IX(i+1, j, m))
                                         +x->at(IX(i-1, j, m))

                                         +x->at(IX(i, j+1, m))
                                         +x->at(IX(i, j-1, m))

                                         +x->at(IX(i, j, m+1))
                                         +x->at(IX(i, j, m-1)))) / c;
                }
            }
        }
        setBoundary(xyz, x);
    }
}

void Fluid::project(std::vector<float>* velocX, std::vector<float>* velocY, std::vector<float>* velocZ, std::vector<float>* p, std::vector<float>* div)
{
    int index;

    //compute divergent vector field
    for (int k = 1; k < N - 1; k++) {
        for (int j = 1; j < N - 1; j++) {
            for (int i = 1; i < N - 1; i++) {

                index = IX(i, j, k);
                div->at(index) = -0.5f * (velocX->at(IX(i+1, j, k)) - velocX->at(IX(i-1, j, k))
                                         +velocY->at(IX(i, j+1, k)) - velocY->at(IX(i, j-1, k))
                                         +velocZ->at(IX(i, j, k+1)) - velocZ->at(IX(i, j, k-1)))/N;
                p->at(index) = 0;
            }
        }
    }
    setBoundary(0, div);
    setBoundary(0, p);
    linearSolve(0, p, div, 1, 6);

    //project divergent vector field at velocity fields to get mass conserving fields
    for (int k = 1; k < N - 1; k++) {
        for (int j = 1; j < N - 1; j++) {
            for (int i = 1; i < N - 1; i++) {

                index = IX(i, j, k);
                velocX->at(index) -= 0.5f * (p->at(IX(i+1, j, k)) - p ->at(IX(i-1, j, k))) * N;
                velocY->at(index) -= 0.5f * (p->at(IX(i, j+1, k)) - p ->at(IX(i, j-1, k))) * N;
                velocZ->at(index) -= 0.5f * (p->at(IX(i, j, k+1)) - p ->at(IX(i, j, k-1))) * N;
            }
        }
    }
    setBoundary(1, velocX);
    setBoundary(2, velocY);
    setBoundary(3, velocZ);
}

void Fluid::advect(int xyz, std::vector<float>* d, std::vector<float>* d0,
                   std::vector<float>* velocityX, std::vector<float>* velocityY, std::vector<float>* velocityZ, float timeStep){

    float i0, i1, j0, j1, k0, k1;
    float s0, s1, t0, t1, u0, u1;
    float x, y, z;
    int index;
    float tStep = timeStep * (N - 2);

    for(int k = 1; k < N - 1; k++){
        for(int j = 1; j < N - 1; j++){
            for(int i = 1; i < N - 1; i++){
                index = IX(i, j, k);

                x = i - tStep * velocityX->at(index);
                y = j - tStep * velocityY->at(index);
                z = k - tStep * velocityZ->at(index);

                if(x < 0.5f) x = 0.5f;
                if(x > N + 0.5f) x = N + 0.5f;
                i0 = floorf(x);
                i1 = i0 + 1.0f;

                if(y < 0.5f) y = 0.5f;
                if(y > N + 0.5f) y = N + 0.5f;
                j0 = floorf(y);
                j1 = j0 + 1.0f;

                if(z < 0.5f) z = 0.5f;
                if(z > N + 0.5f) z = N + 0.5f;
                k0 = floorf(z);
                k1 = k0 + 1.0f;

                s1 = x - i0;
                s0 = 1.0f - s1;
                t1 = y - j0;
                t0 = 1.0f - t1;
                u1 = z - k0;
                u0 = 1.0f - u1;

                d->at(IX(i, j, k)) = s0 * (t0 *(u0 * d0->at(IX((int)i0, (int)j0, (int)k0)) + u1 * d0->at(IX((int)i0, (int)j0, (int)k1)))
                                        + (t1 *(u0 * d0->at(IX((int)i0, (int)j1, (int)k0)) + u1 * d0->at(IX((int)i0, (int)j1, (int)k1)))))
                                    +s1 * (t0 *(u0 * d0->at(IX((int)i1, (int)j0, (int)k0)) + u1 * d0->at(IX((int)i1, (int)j0, (int)k1)))
                                        + (t1 *(u0 * d0->at(IX((int)i1, (int)j1, (int)k0)) + u1 * d0->at(IX((int)i1, (int)j1, (int)k1)))));
                }
          }
    }
    setBoundary(xyz, d);
}

void Fluid::diffuse (int xyz, std::vector<float>* x, std::vector<float>* x0, float diff, float timeStep){
    float a = timeStep * diff * (N - 2) * (N - 2);
    linearSolve(xyz, x, x0, a, 1 + 6 * a);
}


void Fluid::fluidTimeStep(){

    //diffuse velocity
    diffuse(1, &prevValX, &velocX, viscosity, timeStep);
    diffuse(2, &prevValY, &velocY, viscosity, timeStep);
    diffuse(2, &prevValZ, &velocZ, viscosity, timeStep);
    project(&prevValX, &prevValY, &prevValZ, &velocX, &velocY);

    //velocity advection
    advect(1, &velocX, &prevValX, &prevValX, &prevValY, &prevValZ, timeStep);
    advect(2, &velocY, &prevValY, &prevValX, &prevValY, &prevValZ, timeStep);
    advect(2, &velocZ, &prevValZ, &prevValX, &prevValY, &prevValZ, timeStep);
    project(&velocX, &velocY, &velocZ, &prevValX, &prevValY);

    //diffuse and advect density
    diffuse(0, &prevDensity, &density, diffusion, timeStep);
    advect(0, &density, &prevDensity, &velocX, &velocY, &velocZ, timeStep);
}

openglWindow::openglWindow(QWidget *parent){
    QSurfaceFormat format;
    format.setProfile(QSurfaceFormat::CompatibilityProfile);
    setFormat(format);

    fluid = new Fluid(0.1f, 0.00055f, 0.0000001f);

    timeStarted = false;
}

openglWindow::~openglWindow(){}

void openglWindow::initializeGL(){
    glEnable(GL_DEPTH_TEST);

    fluid->initTF();

    fluid->initGrid();

    m_vao.create();
    m_vao.bind();

    m_vertexPositionBuffer = new QOpenGLBuffer(QOpenGLBuffer::VertexBuffer);
    m_vertexColourBuffer = new QOpenGLBuffer(QOpenGLBuffer::VertexBuffer);
    m_vertexIndicesBuffer = new QOpenGLBuffer(QOpenGLBuffer::IndexBuffer);

    //compile and link shaders
    m_shaderProgram.addShaderFromSourceFile(QOpenGLShader::Vertex, "../shaders/vertexShader");
    m_shaderProgram.addShaderFromSourceFile(QOpenGLShader::Fragment, "../shaders/fragmentShader");
    m_shaderProgram.link();

    //positions
    m_vertexPositionBuffer->create();
    m_vertexPositionBuffer->setUsagePattern(QOpenGLBuffer::StaticDraw);

    //colours
    m_vertexColourBuffer->create();
    m_vertexColourBuffer->setUsagePattern(QOpenGLBuffer::StaticDraw);

    //indices
    m_vertexIndicesBuffer->create();
    m_vertexIndicesBuffer->setUsagePattern(QOpenGLBuffer::StaticDraw);

    //current shader program
    m_shaderProgram.bind();

    //bind the position buffer
    m_vertexPositionBuffer->bind();
    m_shaderProgram.enableAttributeArray("position");
    m_shaderProgram.setAttributeBuffer("position", GL_FLOAT, 0, 3);

    //bind the colour buffer
    m_vertexColourBuffer->bind();
    m_shaderProgram.enableAttributeArray("colour");
    m_shaderProgram.setAttributeBuffer("colour", GL_FLOAT, 0, 4);

    m_shaderProgram.setUniformValue("MVPmatrix", QMatrix4x4(arr).transposed());

    resizeGL(this->width(), this->height());
}

void openglWindow::resizeGL(int w, int h){
    glViewport(0,0,w,h);

    float aspectratio = float(w) / float(h);

    projection = glm::perspective(glm::radians(60.0f), aspectratio, 1.0f, (float)N*4);

    view = glm::lookAt(
           glm::vec3(N*1.21f, N*0.8f, N*1.3f),
           glm::vec3(0.0f, 5.0f, 0.0f),
           glm::vec3(0.0f, 1.0f, 0.0f));

    //model view projection matrix
    glm::mat4 mvp = projection * view;

    //convert from glm matrix to array
    const float *pSource = (const float*)glm::value_ptr(mvp);
    for (int i = 0; i < 16; ++i)
        arr[i] = pSource[i];

}

void Fluid::initTF(){

    //control points, 100 values in a transfer function
    QVector3D color0 = {0.1f, 0.05f, 0.01f};
    QVector3D color1 = {0.71f, 0.31f, 0.02f};
    QVector3D color2 = {0.76f, 0.58f, 0.24f};
    QVector3D color3 = {0.84f, 0.84f, 0.06f};
    QVector3D color4 = {0.8f, 0.8f, 0.6f};

    for(float i = 0.0f; i < 0.9f; i+= 0.03f){
        tFunction.push_back(color0 + (color1 - color0) * i);
    }
    for(float i = 0.0f; i < 1.0f; i+= 0.02f){
        tFunction.push_back(color1 + (color2 - color1) * i);
    }
    for(float i = 0.0f; i < 0.9f; i+= 0.1f){
        tFunction.push_back(color2 + (color3 - color2) * i);
    }
    for(float i = 0.0f; i < 0.9f; i+= 0.1f){
        tFunction.push_back(color3 + (color4 - color3) * i);
    }
}

void Fluid::initGrid(){

    //create positions of vertices in a grid
    for (int z = 0; z < N+1; z++) {

        for (int y = 0; y < N+1; y++) {

            for (int x = 0; x < N+1; x++) {

                gridVertices.push_back(x);
                gridVertices.push_back(y);
                gridVertices.push_back(z);

            }
        }
    }
}

void Fluid::DrawGrid(){
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    float dens;

    //reset indices
    gridIndices.clear();

    //vertices of a cube
    int v0, v1, v2, v3 ,v4, v5, v6, v7;

    //create indices of vertices for each cube which has density > 0
    for (int k = 0; k < N; ++k) {

        for (int j = 0; j < N; ++j) {

            for (int i = 0; i < N; ++i) {

                dens = density[IX(i, j, k)];

                if(dens > 0.01){

                    v0 = index(i, j, k);
                    v1 = index(i + 1, j, k);
                    v2 = index(i + 1, j, k + 1);
                    v3 = index(i, j, k + 1);
                    v4 = index(i, j + 1, k);
                    v5 = index(i + 1, j + 1, k);
                    v6 = index(i + 1, j + 1, k + 1);
                    v7 = index(i, j + 1, k + 1);

                    //bottom
                    gridIndices.push_back(v0);
                    gridIndices.push_back(v1);
                    gridIndices.push_back(v2);
                    gridIndices.push_back(v3);
                    //top
                    gridIndices.push_back(v4);
                    gridIndices.push_back(v5);
                    gridIndices.push_back(v6);
                    gridIndices.push_back(v7);
                    //back
                    gridIndices.push_back(v0);
                    gridIndices.push_back(v3);
                    gridIndices.push_back(v7);
                    gridIndices.push_back(v4);
                    //front
                    gridIndices.push_back(v1);
                    gridIndices.push_back(v2);
                    gridIndices.push_back(v6);
                    gridIndices.push_back(v5);
                    //left
                    gridIndices.push_back(v0);
                    gridIndices.push_back(v4);
                    gridIndices.push_back(v5);
                    gridIndices.push_back(v1);
                    //right
                    gridIndices.push_back(v2);
                    gridIndices.push_back(v3);
                    gridIndices.push_back(v7);
                    gridIndices.push_back(v6);

                }
            }
        }
    }

    //find which vertices need to find the colour
    std::vector<float> tempPos;
    tempPos.resize(gridVertices.size(), -1);

    //array for storing new values of old indices: tempIndices[x] = something, where x is the old index and something is a new one
    std::vector<int> tempIndices;
    tempIndices.resize(gridVertices.size(), -1);
    //counter for calculating new value of old index
    int counter = 0;

    neededGridVertices.clear();

    unsigned int index;
    for(int q = 0; q < gridIndices.size(); ++q){

        //index of a vertex to be checked
        index = gridIndices[q];
        //if pos is not set, add it to tempPos
        if(tempPos[index*3] < 0){
            tempPos[index * 3]     = gridVertices[index * 3];      // set the x coorinate to know that this vertex is done

            neededGridVertices.push_back(gridVertices[index * 3]);
            neededGridVertices.push_back(gridVertices[index * 3+1]);
            neededGridVertices.push_back(gridVertices[index * 3+2]);

            //change an index only if it has not been set before
            if(tempIndices[index] < 0){
                tempIndices[index] = counter;
                ++counter;
            }
        }
    }

    //swap old indices with new ones
    neededGridIndices.clear();
    for(int t = 0; t < gridIndices.size(); ++t){
        neededGridIndices.push_back(tempIndices[gridIndices[t]]);
    }


    //calculate colours

    //reset densities and colours array
    gridColors.clear();

    //path from light source to vertex
    std::vector<QVector3D> path;
    //sum of densities along the path
    float densSum;
    int tfIndex;
    float vx, vy, vz;

    for(int vertex = 0; vertex < neededGridVertices.size()/3; ++vertex){
        densSum = 0;
        vx = neededGridVertices[vertex * 3];
        vy = neededGridVertices[vertex * 3 + 1];
        vz = neededGridVertices[vertex * 3 + 2];

        path = findPath(QVector3D(11,1,11), QVector3D(vx, vy, vz));

        if(path.size() > 1){
            for(int c = 0; c < path.size(); ++c){
                densSum += density[IX(path[c].x(), path[c].y(), path[c].z())];
            }
        }
        densSum/=50;

        if(densSum > 0.99) densSum = 0.99f;

        if(densSum < 0.01) densSum = 0;
        densSum *= 100;

        tfIndex = densSum;

        dens = density[IX(vx, vy, vz)];

        gridColors.push_back(tFunction[tfIndex].x());
        gridColors.push_back(tFunction[tfIndex].y());
        gridColors.push_back(tFunction[tfIndex].z());

        gridColors.push_back(dens); //dens as alpha

        density[IX(vx, vy, vz)] -= 0.008f; //make the smoke disappear
    }

}

void openglWindow::paintGL()
{
    glClearColor(0.25f, 0.25f, 0.25f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    if(!timeStarted){
        time.start();
        timeStarted = true;
    }
    else{
        std::cout << "FPS = " << (int)(1000.0f/time.elapsed()) << std::endl;

    }
    time.restart();


    fluid->fluidTimeStep();

    fluid->DrawGrid();

    m_vertexPositionBuffer->bind();
    m_vertexPositionBuffer->allocate(fluid->neededGridVertices.data(),fluid->neededGridVertices.size() * sizeof(float));

    m_vertexColourBuffer->bind();
    m_vertexColourBuffer->allocate(fluid->gridColors.data(), fluid->gridColors.size() * sizeof(float));

    m_vertexIndicesBuffer->bind();
    m_vertexIndicesBuffer->allocate(fluid->neededGridIndices.data(), fluid->neededGridIndices.size() * sizeof(unsigned int));

    m_shaderProgram.bind();
    m_vao.bind();

    glDrawElements(GL_QUADS, fluid->neededGridIndices.size(), GL_UNSIGNED_INT, 0);

    glFlush();
    this->update();
}

void openglWindow::resizeEvent(QResizeEvent *event)
{
    resizeGL(this->width(), this->height());
    this->update();
}

void openglWindow::paintEvent(QPaintEvent *event)
{
    paintGL();
}




