#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtOpenGL>
#include <QOpenGLWindow>
#include <QOpenGLFunctions>
#include <gl/GLU.h>
#include <vector>
#include <../glm/glm.hpp>
#include <../glm/gtc/type_ptr.hpp>



#define N 27
#define scale 25
#define iterations 4

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H

class Fluid
{

public:
    Fluid(float timeStep, float diffusion, float viscosity);
    void drawFluid();
    void DrawGrid();
    void initGrid();
    void initTF();

    std::vector<float> gridVertices;                //all vertices of the grid
    std::vector<float> neededGridVertices;          //vertices which belong to voxels which have density > 0
    std::vector<unsigned int> gridIndices;          //all indices of voxels in a grid
    std::vector<unsigned int> neededGridIndices;    //indices of voxels with density > 0
    std::vector<float> gridColors;                  //colors for neededVertices set based on the transfer function
    //transfer function colors
    std::vector<QVector3D> tFunction;               //transfer function lookup table

    float timeStep;
    float diffusion;
    float viscosity;

    //densities storage
    std::vector<float> prevDensity;
    std::vector<float> density;

    //storage for previous values
    std::vector<float> prevValX;
    std::vector<float> prevValY;
    std::vector<float> prevValZ;

    //velocity values
    std::vector<float> velocX;
    std::vector<float> velocY;
    std::vector<float> velocZ;

    //fluid simulation
    void addDensity(int x, int y, int z, float amount);
    void addVelocity(int x, int y, int z, float amountX, float amountY, float amountZ);
    void setBoundary(int xyz, std::vector<float>* x);
    void linearSolve(int xyz, std::vector<float>* x, std::vector<float>* x0, float a, float c);
    void project(std::vector<float>* velocX, std::vector<float>* velocY, std::vector<float>* velocZ, std::vector<float>* p, std::vector<float>* div);
    void advect(int xyz, std::vector<float>* d, std::vector<float>* d0,  std::vector<float>* velocX, std::vector<float>* velocY, std::vector<float>* velocZ, float timeStep);
    void diffuse (int xyz, std::vector<float>* x, std::vector<float>* x0, float diff, float timeStep);
    void fluidTimeStep();
};

class openglWindow : public QOpenGLWindow
{

    Q_OBJECT

    public:
        openglWindow(QWidget *parent = 0);
        ~openglWindow();

        Fluid* fluid;

        glm::mat4 model;
        glm::mat4 view;
        glm::mat4 projection;

        float arr[16];

        float* vertices;
        float* colours;

        QOpenGLShaderProgram m_shaderProgram;
        QOpenGLBuffer* m_vertexPositionBuffer;
        QOpenGLBuffer* m_vertexIndicesBuffer;
        QOpenGLBuffer* m_vertexColourBuffer;
        QOpenGLVertexArrayObject m_vao;

        bool timeStarted;
        QTime time;




    protected:
        virtual void initializeGL() ;
        virtual void resizeGL(int w, int h);
        virtual void paintGL();
        void resizeEvent(QResizeEvent *event);
        void paintEvent(QPaintEvent *event);
};





